import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Dashboard } from "./components/Dashboard";
import { AssetList } from "./components/assets/AssetList";
import { AssetGroupView } from "./components/assets/AssetGroupView";
import { AssetBatchView } from "./components/assets/AssetBatchView";
import { AssetForm } from "./components/assets/AssetForm";
import { AssetDetail } from "./components/assets/AssetDetail";
import { DepreciationList } from "./components/depreciation/DepreciationList";
import { AllocationList } from "./components/allocation/AllocationList";
import { MaintenanceList } from "./components/maintenance/MaintenanceList";
import { MaintenanceForm } from "./components/maintenance/MaintenanceForm";
import { LiquidationList } from "./components/liquidation/LiquidationList";
import { LiquidationForm } from "./components/liquidation/LiquidationForm";
import { VoucherList } from "./components/vouchers/VoucherList";
import { VoucherDetail } from "./components/vouchers/VoucherDetail";
import { Reports } from "./components/reports/Reports";
import { AdminPanel } from "./components/admin/AdminPanel";
import { NotFound } from "./components/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "assets", Component: AssetList },
      { path: "assets/groups", Component: AssetGroupView },
      { path: "assets/batch", Component: AssetBatchView },
      { path: "assets/new", Component: AssetForm },
      { path: "assets/:id", Component: AssetDetail },
      { path: "assets/:id/edit", Component: AssetForm },
      { path: "depreciation", Component: DepreciationList },
      { path: "allocation", Component: AllocationList },
      { path: "maintenance", Component: MaintenanceList },
      { path: "maintenance/new", Component: MaintenanceForm },
      { path: "liquidation", Component: LiquidationList },
      { path: "liquidation/new", Component: LiquidationForm },
      { path: "vouchers", Component: VoucherList },
      { path: "vouchers/:id", Component: VoucherDetail },
      { path: "reports", Component: Reports },
      { path: "admin", Component: AdminPanel },
      { path: "*", Component: NotFound },
    ],
  },
]);
