import { Outlet, Link, useLocation } from 'react-router';
import { 
  LayoutDashboard, 
  Package, 
  TrendingDown, 
  ArrowLeftRight, 
  Wrench, 
  Trash2, 
  FileText, 
  BarChart3, 
  Settings,
  Bell,
  User,
  LogOut,
  Menu,
  X
} from 'lucide-react';
import { useState } from 'react';

interface NavItem {
  path: string;
  label: string;
  icon: React.ElementType;
}

const navItems: NavItem[] = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/assets', label: 'Quản lý Tài sản', icon: Package },
  { path: '/depreciation', label: 'Khấu hao', icon: TrendingDown },
  { path: '/allocation', label: 'Cấp phát & Điều chuyển', icon: ArrowLeftRight },
  { path: '/maintenance', label: 'Bảo trì - Bảo dưỡng', icon: Wrench },
  { path: '/liquidation', label: 'Thanh lý', icon: Trash2 },
  { path: '/vouchers', label: 'Chứng từ Kế toán', icon: FileText },
  { path: '/reports', label: 'Báo cáo', icon: BarChart3 },
  { path: '/admin', label: 'Quản trị', icon: Settings },
];

export function Layout() {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside 
        className={`bg-gradient-to-b from-blue-900 to-blue-800 text-white transition-all duration-300 ${
          sidebarOpen ? 'w-64' : 'w-0'
        } overflow-hidden`}
      >
        <div className="p-6 border-b border-blue-700">
          <h1 className="font-bold text-xl">TSCĐ Manager</h1>
          <p className="text-blue-200 text-sm mt-1">Quản lý Tài sản Cố định</p>
        </div>
        
        <nav className="p-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path || 
              (item.path !== '/' && location.pathname.startsWith(item.path));
            
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  isActive 
                    ? 'bg-white text-blue-900 font-medium shadow-sm' 
                    : 'text-blue-100 hover:bg-blue-800'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-blue-700">
          <div className="flex items-center gap-3 px-4 py-2">
            <div className="w-8 h-8 rounded-full bg-blue-700 flex items-center justify-center">
              <User className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">Nguyễn Văn A</p>
              <p className="text-xs text-blue-200">Kế toán trưởng</p>
            </div>
            <button className="text-blue-200 hover:text-white">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="text-gray-600 hover:text-gray-900"
            >
              {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            
            <div className="flex items-center gap-4">
              <button className="relative text-gray-600 hover:text-gray-900">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-white text-xs flex items-center justify-center">
                  3
                </span>
              </button>
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">Công ty TNHH ABC</p>
                <p className="text-xs text-gray-500">Hôm nay: {new Date().toLocaleDateString('vi-VN')}</p>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
