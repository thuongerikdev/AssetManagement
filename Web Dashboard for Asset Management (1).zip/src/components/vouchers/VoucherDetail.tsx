import { useParams, useNavigate } from 'react-router';
import { ArrowLeft, FileText, Lock, Printer, Download } from 'lucide-react';

export function VoucherDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  // Mock data
  const voucher = {
    id: id,
    code: 'CT-2026-KH-045',
    date: '2026-02-01',
    type: 'Khấu hao TSCĐ',
    description: 'Khấu hao TSCĐ tháng 01/2026',
    status: 'posted',
    createdBy: 'Nguyễn Thị Kế toán',
    createdDate: '2026-02-01',
    postedBy: 'Trần Văn Trưởng phòng',
    postedDate: '2026-02-02',
  };

  const entries = [
    {
      id: 1,
      debitAccount: '627',
      debitAccountName: 'Chi phí sản xuất chung',
      creditAccount: '214',
      creditAccountName: 'Hao mòn TSCĐ',
      amount: 2361111,
      description: 'KH LAP-001 - MacBook Pro 16"',
      assetCode: 'LAP-001'
    },
    {
      id: 2,
      debitAccount: '627',
      debitAccountName: 'Chi phí sản xuất chung',
      creditAccount: '214',
      creditAccountName: 'Hao mòn TSCĐ',
      amount: 4166667,
      description: 'KH SRV-001 - Dell PowerEdge R740',
      assetCode: 'SRV-001'
    },
    {
      id: 3,
      debitAccount: '627',
      debitAccountName: 'Chi phí sản xuất chung',
      creditAccount: '214',
      creditAccountName: 'Hao mòn TSCĐ',
      amount: 416667,
      description: 'KH MON-045 - LG UltraWide 34"',
      assetCode: 'MON-045'
    },
    {
      id: 4,
      debitAccount: '627',
      debitAccountName: 'Chi phí sản xuất chung',
      creditAccount: '214',
      creditAccountName: 'Hao mòn TSCĐ',
      amount: 2000000,
      description: 'KH LAP-012 - Dell XPS 15',
      assetCode: 'LAP-012'
    },
  ];

  const totalAmount = entries.reduce((sum, entry) => sum + entry.amount, 0);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(value);
  };

  const isLocked = voucher.status === 'posted' || voucher.status === 'locked';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/vouchers')}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-bold text-gray-900">Chi tiết Chứng từ</h1>
            <p className="text-sm text-gray-500 mt-1">{voucher.code}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <Printer className="w-4 h-4" />
            In
          </button>
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <Download className="w-4 h-4" />
            Xuất PDF
          </button>
        </div>
      </div>

      {/* Voucher Info */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-100 rounded-lg">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h2 className="font-bold text-gray-900">{voucher.code}</h2>
              <p className="text-sm text-gray-600 mt-1">{voucher.type}</p>
            </div>
          </div>
          {isLocked && (
            <div className="flex items-center gap-2 px-3 py-2 bg-green-100 text-green-700 rounded-lg">
              <Lock className="w-4 h-4" />
              <span className="text-sm font-medium">Đã ghi sổ</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-6 border-b border-gray-200">
          <div>
            <p className="text-sm text-gray-600 mb-1">Ngày chứng từ</p>
            <p className="font-medium text-gray-900">
              {new Date(voucher.date).toLocaleDateString('vi-VN')}
            </p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Diễn giải</p>
            <p className="font-medium text-gray-900">{voucher.description}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Người lập</p>
            <p className="font-medium text-gray-900">{voucher.createdBy}</p>
            <p className="text-xs text-gray-500">
              {new Date(voucher.createdDate).toLocaleDateString('vi-VN')}
            </p>
          </div>
          {voucher.postedBy && (
            <div>
              <p className="text-sm text-gray-600 mb-1">Người ghi sổ</p>
              <p className="font-medium text-gray-900">{voucher.postedBy}</p>
              <p className="text-xs text-gray-500">
                {new Date(voucher.postedDate).toLocaleDateString('vi-VN')}
              </p>
            </div>
          )}
        </div>

        {isLocked && (
          <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg flex items-center gap-3">
            <Lock className="w-5 h-5 text-yellow-600" />
            <p className="text-sm text-yellow-800">
              Chứng từ đã được ghi sổ và không thể chỉnh sửa
            </p>
          </div>
        )}
      </div>

      {/* Accounting Entries */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
          <h3 className="font-semibold text-gray-900">Bảng định khoản</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  STT
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  TK Nợ
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  TK Có
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Diễn giải
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Số tiền
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {entries.map((entry, index) => (
                <tr key={entry.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {index + 1}
                  </td>
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{entry.debitAccount}</p>
                      <p className="text-xs text-gray-500">{entry.debitAccountName}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{entry.creditAccount}</p>
                      <p className="text-xs text-gray-500">{entry.creditAccountName}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-sm text-gray-900">{entry.description}</p>
                      {entry.assetCode && (
                        <p className="text-xs text-blue-600 mt-1">Mã TS: {entry.assetCode}</p>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className="text-sm font-medium text-gray-900">
                      {formatCurrency(entry.amount)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-gray-50 border-t-2 border-gray-300">
              <tr>
                <td colSpan={4} className="px-6 py-4 text-right font-semibold text-gray-900">
                  Tổng cộng:
                </td>
                <td className="px-6 py-4 text-right font-bold text-blue-600">
                  {formatCurrency(totalAmount)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Related Assets */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Tài sản liên quan</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {entries.map((entry) => (
            <div key={entry.id} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
              <p className="text-sm font-medium text-blue-600">{entry.assetCode}</p>
              <p className="text-xs text-gray-600 mt-1 line-clamp-2">{entry.description}</p>
              <p className="text-xs font-medium text-gray-900 mt-2">
                {formatCurrency(entry.amount)}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Actions */}
      {!isLocked && (
        <div className="flex justify-end gap-4">
          <button
            onClick={() => navigate('/vouchers')}
            className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Đóng
          </button>
          <button className="flex items-center gap-2 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            <Lock className="w-5 h-5" />
            Ghi sổ
          </button>
        </div>
      )}
    </div>
  );
}
