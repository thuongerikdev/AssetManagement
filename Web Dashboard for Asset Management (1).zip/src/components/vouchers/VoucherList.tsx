import { useState } from 'react';
import { Link } from 'react-router';
import { Search, Filter, FileText, Eye, Lock, Unlock, Download } from 'lucide-react';

interface Voucher {
  id: string;
  code: string;
  date: string;
  type: 'increase' | 'depreciation' | 'maintenance' | 'liquidation';
  description: string;
  amount: number;
  status: 'draft' | 'posted' | 'locked';
  assetCode?: string;
}

const mockVouchers: Voucher[] = [
  {
    id: '1',
    code: 'CT-2026-001',
    date: '2026-01-15',
    type: 'increase',
    description: 'Ghi tăng TSCĐ - MacBook Pro 16"',
    amount: 85000000,
    status: 'posted',
    assetCode: 'LAP-001'
  },
  {
    id: '2',
    code: 'CT-2026-KH-045',
    date: '2026-02-01',
    type: 'depreciation',
    description: 'Khấu hao TSCĐ tháng 01/2026',
    amount: 8944445,
    status: 'posted'
  },
  {
    id: '3',
    code: 'CT-2026-BT-012',
    date: '2026-02-10',
    type: 'maintenance',
    description: 'Chi phí sửa chữa - Thay pin laptop',
    amount: 5000000,
    status: 'posted',
    assetCode: 'LAP-012'
  },
  {
    id: '4',
    code: 'CT-2026-TL-003',
    date: '2026-02-15',
    type: 'liquidation',
    description: 'Thanh lý TSCĐ - Dell Latitude 7490',
    amount: 3000000,
    status: 'posted',
    assetCode: 'LAP-023'
  },
  {
    id: '5',
    code: 'CT-2026-KH-046',
    date: '2026-02-28',
    type: 'depreciation',
    description: 'Khấu hao TSCĐ tháng 02/2026',
    amount: 8944445,
    status: 'draft'
  },
];

const typeConfig = {
  increase: { label: 'Ghi tăng', color: 'bg-green-100 text-green-700' },
  depreciation: { label: 'Khấu hao', color: 'bg-orange-100 text-orange-700' },
  maintenance: { label: 'Bảo trì', color: 'bg-blue-100 text-blue-700' },
  liquidation: { label: 'Thanh lý', color: 'bg-red-100 text-red-700' },
};

const statusConfig = {
  draft: { label: 'Nháp', color: 'bg-gray-100 text-gray-700', icon: FileText },
  posted: { label: 'Đã ghi sổ', color: 'bg-green-100 text-green-700', icon: Lock },
  locked: { label: 'Đã khóa', color: 'bg-red-100 text-red-700', icon: Lock },
};

export function VoucherList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredVouchers = mockVouchers.filter(voucher => {
    const matchesSearch = voucher.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      voucher.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || voucher.type === filterType;
    const matchesStatus = filterStatus === 'all' || voucher.status === filterStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-gray-900">Chứng từ Kế toán</h1>
          <p className="text-sm text-gray-500 mt-1">Danh sách chứng từ tài sản cố định</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
          <Download className="w-5 h-5" />
          Xuất Excel
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <p className="text-sm text-gray-600 mb-1">Tổng chứng từ</p>
          <p className="font-bold text-gray-900">156 chứng từ</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <p className="text-sm text-gray-600 mb-1">Chờ ghi sổ</p>
          <p className="font-bold text-yellow-600">3 chứng từ</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <p className="text-sm text-gray-600 mb-1">Đã ghi sổ</p>
          <p className="font-bold text-green-600">148 chứng từ</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <p className="text-sm text-gray-600 mb-1">Đã khóa</p>
          <p className="font-bold text-red-600">5 chứng từ</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Tìm kiếm theo số chứng từ hoặc diễn giải..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">Tất cả loại</option>
              <option value="increase">Ghi tăng</option>
              <option value="depreciation">Khấu hao</option>
              <option value="maintenance">Bảo trì</option>
              <option value="liquidation">Thanh lý</option>
            </select>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="draft">Nháp</option>
              <option value="posted">Đã ghi sổ</option>
              <option value="locked">Đã khóa</option>
            </select>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-5 h-5" />
              Bộ lọc
            </button>
          </div>
        </div>
      </div>

      {/* Vouchers Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Số chứng từ
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Ngày
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Loại
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Diễn giải
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Số tiền
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Trạng thái
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Thao tác
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredVouchers.map((voucher) => {
                const StatusIcon = statusConfig[voucher.status].icon;
                return (
                  <tr key={voucher.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <Link to={`/vouchers/${voucher.id}`} className="text-sm font-medium text-blue-600 hover:underline">
                        {voucher.code}
                      </Link>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm text-gray-900">
                        {new Date(voucher.date).toLocaleDateString('vi-VN')}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${typeConfig[voucher.type].color}`}>
                        {typeConfig[voucher.type].label}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-sm text-gray-900">{voucher.description}</p>
                        {voucher.assetCode && (
                          <p className="text-xs text-gray-500 mt-1">Mã TS: {voucher.assetCode}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className="text-sm font-medium text-gray-900">
                        {formatCurrency(voucher.amount)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full ${statusConfig[voucher.status].color}`}>
                        <StatusIcon className="w-3 h-3" />
                        {statusConfig[voucher.status].label}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <div className="flex items-center justify-center gap-2">
                        <Link
                          to={`/vouchers/${voucher.id}`}
                          className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                          title="Xem chi tiết"
                        >
                          <Eye className="w-4 h-4" />
                        </Link>
                        {voucher.status === 'draft' && (
                          <button
                            className="p-1 text-green-600 hover:bg-green-50 rounded transition-colors"
                            title="Ghi sổ"
                          >
                            <Unlock className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
