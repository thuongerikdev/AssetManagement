import { useState } from 'react';
import { FileText, Download, Calendar, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export function Reports() {
  const [reportType, setReportType] = useState('asset-by-dept');
  const [fromDate, setFromDate] = useState('2026-01-01');
  const [toDate, setToDate] = useState('2026-02-28');

  // Mock data for different reports
  const assetByDeptData = [
    { department: 'IT', count: 450, value: 12500000000 },
    { department: 'Kỹ thuật', count: 320, value: 8900000000 },
    { department: 'Sales', count: 180, value: 4200000000 },
    { department: 'Marketing', count: 145, value: 3800000000 },
    { department: 'Admin', count: 139, value: 2100000000 },
  ];

  const assetMovementData = [
    { month: 'T1', increase: 45, decrease: 12, increaseValue: 850000000, decreaseValue: 120000000 },
    { month: 'T2', increase: 52, decrease: 8, increaseValue: 920000000, decreaseValue: 85000000 },
    { month: 'T3', increase: 38, decrease: 15, increaseValue: 680000000, decreaseValue: 180000000 },
    { month: 'T4', increase: 61, decrease: 10, increaseValue: 1100000000, decreaseValue: 95000000 },
    { month: 'T5', increase: 55, decrease: 18, increaseValue: 980000000, decreaseValue: 220000000 },
    { month: 'T6', increase: 67, decrease: 9, increaseValue: 1250000000, decreaseValue: 78000000 },
  ];

  const depreciationData = [
    { month: 'T1/2026', amount: 284000000 },
    { month: 'T2/2026', amount: 285000000 },
    { month: 'T3/2026', amount: 282000000 },
    { month: 'T4/2026', amount: 290000000 },
    { month: 'T5/2026', amount: 288000000 },
    { month: 'T6/2026', amount: 292000000 },
  ];

  const maintenanceCostData = [
    { category: 'Sửa chữa', cost: 125000000, color: '#f59e0b' },
    { category: 'Nâng cấp', cost: 285000000, color: '#3b82f6' },
    { category: 'Bảo trì định kỳ', cost: 95000000, color: '#10b981' },
    { category: 'Khác', cost: 42000000, color: '#8b5cf6' },
  ];

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
      notation: 'compact',
      compactDisplay: 'short'
    }).format(value);
  };

  const formatFullCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-gray-900">Báo cáo</h1>
          <p className="text-sm text-gray-500 mt-1">Báo cáo và phân tích tài sản cố định</p>
        </div>
      </div>

      {/* Report Filter */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Loại báo cáo
            </label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="asset-by-dept">Báo cáo Tài sản theo Phòng ban</option>
              <option value="asset-movement">Báo cáo Tăng giảm Tài sản</option>
              <option value="depreciation">Báo cáo Khấu hao</option>
              <option value="maintenance-cost">Báo cáo Chi phí Bảo trì</option>
              <option value="asset-ledger">Sổ Tài sản</option>
              <option value="account-ledger">Sổ cái Tài khoản</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Từ ngày
            </label>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Đến ngày
            </label>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
        <div className="flex gap-2 mt-4">
          <button className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <FileText className="w-5 h-5" />
            Xem báo cáo
          </button>
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <Download className="w-5 h-5" />
            Xuất Excel
          </button>
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <Download className="w-5 h-5" />
            Xuất PDF
          </button>
        </div>
      </div>

      {/* Report Content */}
      {reportType === 'asset-by-dept' && (
        <div className="space-y-6">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Tài sản theo Phòng ban</h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Phòng ban</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase">Số lượng</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase">Tổng giá trị</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase">Tỷ lệ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {assetByDeptData.map((dept) => {
                    const total = assetByDeptData.reduce((sum, d) => sum + d.value, 0);
                    const percentage = ((dept.value / total) * 100).toFixed(1);
                    return (
                      <tr key={dept.department} className="hover:bg-gray-50">
                        <td className="px-6 py-4 text-sm font-medium text-gray-900">{dept.department}</td>
                        <td className="px-6 py-4 text-sm text-right text-gray-900">{dept.count}</td>
                        <td className="px-6 py-4 text-sm text-right font-medium text-gray-900">
                          {formatFullCurrency(dept.value)}
                        </td>
                        <td className="px-6 py-4 text-sm text-right text-gray-600">{percentage}%</td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot className="bg-gray-50 border-t-2 border-gray-300">
                  <tr>
                    <td className="px-6 py-4 font-semibold text-gray-900">Tổng cộng</td>
                    <td className="px-6 py-4 text-right font-semibold text-gray-900">
                      {assetByDeptData.reduce((sum, d) => sum + d.count, 0)}
                    </td>
                    <td className="px-6 py-4 text-right font-bold text-blue-600">
                      {formatFullCurrency(assetByDeptData.reduce((sum, d) => sum + d.value, 0))}
                    </td>
                    <td className="px-6 py-4 text-right font-semibold text-gray-900">100%</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Biểu đồ phân bổ</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={assetByDeptData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="department" />
                <YAxis />
                <Tooltip formatter={(value: any) => formatCurrency(value)} />
                <Legend />
                <Bar dataKey="value" fill="#3b82f6" name="Giá trị (VNĐ)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {reportType === 'asset-movement' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-green-100 rounded-lg">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Tổng Tăng</p>
                  <p className="font-bold text-gray-900">318 tài sản</p>
                  <p className="text-xs text-green-600 mt-1">5.78 tỷ VNĐ</p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-red-100 rounded-lg">
                  <TrendingDown className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Tổng Giảm</p>
                  <p className="font-bold text-gray-900">72 tài sản</p>
                  <p className="text-xs text-red-600 mt-1">778 triệu VNĐ</p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <DollarSign className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Tăng ròng</p>
                  <p className="font-bold text-gray-900">246 tài sản</p>
                  <p className="text-xs text-blue-600 mt-1">5.00 tỷ VNĐ</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Biểu đồ Tăng giảm theo tháng</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={assetMovementData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="increase" fill="#10b981" name="Tăng" />
                <Bar dataKey="decrease" fill="#ef4444" name="Giảm" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {reportType === 'depreciation' && (
        <div className="space-y-6">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Chi phí Khấu hao theo tháng</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={depreciationData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value: any) => formatCurrency(value)} />
                <Legend />
                <Line type="monotone" dataKey="amount" stroke="#f59e0b" strokeWidth={2} name="Khấu hao (VNĐ)" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Chi tiết Khấu hao</h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase">Tháng</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase">Số tiền</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {depreciationData.map((item) => (
                    <tr key={item.month} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm text-gray-900">{item.month}</td>
                      <td className="px-6 py-4 text-sm text-right font-medium text-gray-900">
                        {formatFullCurrency(item.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-gray-50 border-t-2 border-gray-300">
                  <tr>
                    <td className="px-6 py-4 font-semibold text-gray-900">Tổng cộng</td>
                    <td className="px-6 py-4 text-right font-bold text-blue-600">
                      {formatFullCurrency(depreciationData.reduce((sum, d) => sum + d.amount, 0))}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      )}

      {reportType === 'maintenance-cost' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Chi phí theo Loại</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={maintenanceCostData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="cost"
                  >
                    {maintenanceCostData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: any) => formatCurrency(value)} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Chi tiết Chi phí</h3>
              <div className="space-y-4">
                {maintenanceCostData.map((item) => (
                  <div key={item.category} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 rounded" style={{ backgroundColor: item.color }}></div>
                      <span className="text-sm font-medium text-gray-900">{item.category}</span>
                    </div>
                    <span className="text-sm font-semibold text-gray-900">
                      {formatFullCurrency(item.cost)}
                    </span>
                  </div>
                ))}
                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
                  <span className="text-sm font-semibold text-blue-900">Tổng cộng</span>
                  <span className="font-bold text-blue-900">
                    {formatFullCurrency(maintenanceCostData.reduce((sum, d) => sum + d.cost, 0))}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
