import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { Plus, Search, Filter, Eye, Send, ArrowLeftRight, Trash2, Download, Package, Layers } from 'lucide-react';

interface Asset {
  id: string;
  code: string;
  name: string;
  type: string;
  department: string;
  user: string;
  originalValue: number;
  remainingValue: number;
  status: 'active' | 'maintenance' | 'liquidated';
  batchId?: string;
  batchIndex?: number;
  batchTotal?: number;
}

const mockAssets: Asset[] = [
  {
    id: '1',
    code: 'LAP-001',
    name: 'MacBook Pro 16" M3 Max',
    type: 'Laptop',
    department: 'IT',
    user: 'Nguyễn Văn A',
    originalValue: 85000000,
    remainingValue: 68000000,
    status: 'active'
  },
  {
    id: '2',
    code: 'SRV-001',
    name: 'Dell PowerEdge R740',
    type: 'Server',
    department: 'IT',
    user: 'Trần Thị B',
    originalValue: 250000000,
    remainingValue: 187500000,
    status: 'active'
  },
  {
    id: '3',
    code: 'MON-045',
    name: 'LG UltraWide 34"',
    type: 'Monitor',
    department: 'Marketing',
    user: 'Lê Văn C',
    originalValue: 15000000,
    remainingValue: 9000000,
    status: 'active'
  },
  {
    id: '4',
    code: 'LAP-012',
    name: 'Dell XPS 15',
    type: 'Laptop',
    department: 'Sales',
    user: 'Phạm Thị D',
    originalValue: 45000000,
    remainingValue: 22500000,
    status: 'maintenance'
  },
  {
    id: '5',
    code: 'PRT-008',
    name: 'HP LaserJet Pro M404',
    type: 'Printer',
    department: 'Admin',
    user: 'Hoàng Văn E',
    originalValue: 8000000,
    remainingValue: 2400000,
    status: 'active'
  },
];

const statusConfig = {
  active: { label: 'Đang sử dụng', color: 'bg-green-100 text-green-700' },
  maintenance: { label: 'Bảo trì', color: 'bg-orange-100 text-orange-700' },
  liquidated: { label: 'Đã thanh lý', color: 'bg-gray-100 text-gray-700' },
};

export function AssetList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [assets, setAssets] = useState<Asset[]>([]);

  useEffect(() => {
    // Load assets from localStorage
    const storedAssets = JSON.parse(localStorage.getItem('assets') || '[]');
    
    // Convert to Asset format
    const loadedAssets: Asset[] = storedAssets.map((asset: any, index: number) => ({
      id: asset.id || `asset-${index}`,
      code: asset.code,
      name: asset.name,
      type: asset.assetGroup || 'N/A',
      department: asset.department,
      user: asset.recipient || 'Chưa cấp phát',
      originalValue: parseFloat(asset.originalValue) || 0,
      remainingValue: parseFloat(asset.originalValue) || 0, // TODO: Calculate actual remaining value
      status: asset.status || 'active',
      batchId: asset.batchId,
      batchIndex: asset.batchIndex,
      batchTotal: asset.batchTotal,
    }));

    // If no stored assets, use mock data
    setAssets(loadedAssets.length > 0 ? loadedAssets : mockAssets);
  }, []);

  const filteredAssets = assets.filter(asset => {
    const matchesSearch = asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      asset.code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || asset.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-gray-900">Quản lý Tài sản</h1>
          <p className="text-sm text-gray-500 mt-1">Danh sách tài sản cố định</p>
        </div>
        <div className="flex gap-3">
          <Link
            to="/assets/groups"
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Package className="w-5 h-5" />
            Xem theo Nhóm
          </Link>
          <Link
            to="/assets/batch"
            className="flex items-center gap-2 px-4 py-2 border border-purple-300 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors"
          >
            <Layers className="w-5 h-5" />
            Xem theo Lô
          </Link>
          <Link
            to="/assets/new"
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            Thêm Tài sản
          </Link>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Tìm kiếm theo tên hoặc mã tài sản..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="active">Đang sử dụng</option>
              <option value="maintenance">Bảo trì</option>
              <option value="liquidated">Đã thanh lý</option>
            </select>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-5 h-5" />
              Bộ lọc
            </button>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Download className="w-5 h-5" />
              Xuất Excel
            </button>
          </div>
        </div>
      </div>

      {/* Asset Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Mã TS
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Tên tài sản
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Loại
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Phòng ban
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Người dùng
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Nguyên giá
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Giá trị còn lại
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Trạng thái
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Thao tác
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredAssets.map((asset) => (
                <tr key={asset.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-blue-600">{asset.code}</span>
                      {asset.batchId && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-purple-100 text-purple-700 rounded text-xs">
                          <Layers className="w-3 h-3" />
                          Lô {asset.batchIndex}/{asset.batchTotal}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-900">{asset.name}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-600">{asset.type}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-600">{asset.department}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-600">{asset.user}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className="text-sm text-gray-900">{formatCurrency(asset.originalValue)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className="text-sm font-medium text-gray-900">{formatCurrency(asset.remainingValue)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${statusConfig[asset.status].color}`}>
                      {statusConfig[asset.status].label}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <div className="flex items-center justify-center gap-2">
                      <Link
                        to={`/assets/${asset.id}`}
                        className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title="Chi tiết"
                      >
                        <Eye className="w-4 h-4" />
                      </Link>
                      <button
                        className="p-1 text-green-600 hover:bg-green-50 rounded transition-colors"
                        title="Cấp phát"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                      <button
                        className="p-1 text-orange-600 hover:bg-orange-50 rounded transition-colors"
                        title="Điều chuyển"
                      >
                        <ArrowLeftRight className="w-4 h-4" />
                      </button>
                      <button
                        className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                        title="Thanh lý"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between bg-white rounded-lg border border-gray-200 px-6 py-3">
        <p className="text-sm text-gray-600">
          Hiển thị <span className="font-medium">1-{filteredAssets.length}</span> trong tổng số <span className="font-medium">{filteredAssets.length}</span> tài sản
        </p>
        <div className="flex gap-2">
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 transition-colors text-sm">
            Trước
          </button>
          <button className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors text-sm">
            1
          </button>
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 transition-colors text-sm">
            2
          </button>
          <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 transition-colors text-sm">
            Sau
          </button>
        </div>
      </div>
    </div>
  );
}
