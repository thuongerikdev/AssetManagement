import { useState, useEffect } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router';
import { Save, X, AlertCircle, Upload, Calculator, Info, Layers } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

// Cấu hình nhóm tài sản với mã prefix và thông tin khấu hao mặc định
const assetGroupConfig = {
  laptop: {
    name: 'Laptop',
    prefix: 'LAP',
    defaultDepreciationPeriod: 36,
    accountCode: '2113',
    accountName: '2113 - Thiết bị công nghệ',
    fields: ['cpu', 'ram', 'storage', 'display']
  },
  desktop: {
    name: 'Desktop/PC',
    prefix: 'DES',
    defaultDepreciationPeriod: 48,
    accountCode: '2113',
    accountName: '2113 - Thiết bị công nghệ',
    fields: ['cpu', 'ram', 'storage']
  },
  server: {
    name: 'Server',
    prefix: 'SRV',
    defaultDepreciationPeriod: 60,
    accountCode: '2111',
    accountName: '2111 - Máy móc thiết bị',
    fields: ['cpu', 'ram', 'storage', 'raid']
  },
  monitor: {
    name: 'Màn hình',
    prefix: 'MON',
    defaultDepreciationPeriod: 48,
    accountCode: '2112',
    accountName: '2112 - Thiết bị văn phòng',
    fields: ['size', 'resolution']
  },
  printer: {
    name: 'Máy in',
    prefix: 'PRT',
    defaultDepreciationPeriod: 60,
    accountCode: '2112',
    accountName: '2112 - Thiết bị văn phòng',
    fields: ['printType', 'speed']
  },
  network: {
    name: 'Thiết bị mạng',
    prefix: 'NET',
    defaultDepreciationPeriod: 60,
    accountCode: '2111',
    accountName: '2111 - Máy móc thiết bị',
    fields: ['ports', 'speed']
  },
  furniture: {
    name: 'Nội thất văn phòng',
    prefix: 'FUR',
    defaultDepreciationPeriod: 72,
    accountCode: '2112',
    accountName: '2112 - Thiết bị văn phòng',
    fields: ['material', 'dimensions']
  },
  chair: {
    name: 'Ghế văn phòng',
    prefix: 'GHE',
    defaultDepreciationPeriod: 60,
    accountCode: '2112',
    accountName: '2112 - Thiết bị văn phòng',
    fields: ['material', 'dimensions']
  },
  desk: {
    name: 'Bàn làm việc',
    prefix: 'BAN',
    defaultDepreciationPeriod: 72,
    accountCode: '2112',
    accountName: '2112 - Thiết bị văn phòng',
    fields: ['material', 'dimensions']
  },
  other: {
    name: 'Khác',
    prefix: 'OTH',
    defaultDepreciationPeriod: 48,
    accountCode: '2111',
    accountName: '2111 - Máy móc thiết bị',
    fields: []
  }
};

export function AssetForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const isEdit = !!id;
  const isBatchModeFromQuery = searchParams.get('mode') === 'batch';

  const [formData, setFormData] = useState({
    name: '',
    assetGroup: '',
    purchaseDate: '',
    originalValue: '',
    accountCode: '',
    depreciationMethod: 'straight-line',
    depreciationPeriod: '',
    department: '',
    recipient: '',
    serialNumber: '',
    manufacturer: '',
    description: '',
    // Thông tin chi tiết theo nhóm
    cpu: '',
    ram: '',
    storage: '',
    display: '',
    raid: '',
    size: '',
    resolution: '',
    printType: '',
    speed: '',
    ports: '',
    material: '',
    dimensions: '',
  });

  const [previewCode, setPreviewCode] = useState('');
  const [monthlyDepreciation, setMonthlyDepreciation] = useState(0);
  
  // Batch mode states
  const [isBatchMode, setIsBatchMode] = useState(isBatchModeFromQuery);
  const [batchQuantity, setBatchQuantity] = useState(isBatchModeFromQuery ? 10 : 1);
  const [autoGenerateSerial, setAutoGenerateSerial] = useState(isBatchModeFromQuery);

  // Tự động sinh mã tài sản khi chọn nhóm
  useEffect(() => {
    if (formData.assetGroup && !isEdit) {
      const config = assetGroupConfig[formData.assetGroup as keyof typeof assetGroupConfig];
      if (config) {
        const year = new Date().getFullYear();
        
        // In batch mode, calculate next available number from localStorage
        let nextNum;
        if (isBatchMode) {
          const existingAssets = JSON.parse(localStorage.getItem('assets') || '[]');
          const existingCodes = existingAssets
            .filter((a: any) => a.code?.startsWith(config.prefix))
            .map((a: any) => {
              const parts = a.code.split('-');
              return parseInt(parts[2] || '0');
            })
            .filter((n: number) => !isNaN(n));
          
          nextNum = existingCodes.length > 0 ? Math.max(...existingCodes) + 1 : 1;
        } else {
          // Single mode: use random number for preview
          nextNum = Math.floor(Math.random() * 1000);
        }
        
        setPreviewCode(`${config.prefix}-${year}-${nextNum.toString().padStart(3, '0')}`);
        
        // Set default values
        setFormData(prev => ({
          ...prev,
          depreciationPeriod: config.defaultDepreciationPeriod.toString(),
          accountCode: config.accountCode
        }));
      }
    }
  }, [formData.assetGroup, isEdit, isBatchMode]);

  // Tính toán khấu hao dự kiến
  useEffect(() => {
    if (formData.originalValue && formData.depreciationPeriod) {
      const value = parseFloat(formData.originalValue);
      const months = parseFloat(formData.depreciationPeriod);
      if (formData.depreciationMethod === 'straight-line') {
        setMonthlyDepreciation(value / months);
      } else {
        // Phương pháp số dư giảm dần (simplified)
        const rate = (2 / months);
        setMonthlyDepreciation(value * rate);
      }
    } else {
      setMonthlyDepreciation(0);
    }
  }, [formData.originalValue, formData.depreciationPeriod, formData.depreciationMethod]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Load existing assets
    const existingAssets = JSON.parse(localStorage.getItem('assets') || '[]');
    
    if (isBatchMode && batchQuantity > 1) {
      // Batch mode: Create multiple assets
      const batchId = `BATCH-${Date.now()}`;
      const config = assetGroupConfig[formData.assetGroup as keyof typeof assetGroupConfig];
      const year = new Date().getFullYear();
      
      // Find the next available number for this asset group
      const existingCodes = existingAssets
        .filter((a: any) => a.code?.startsWith(config.prefix))
        .map((a: any) => {
          const parts = a.code.split('-');
          return parseInt(parts[2] || '0');
        })
        .filter((n: number) => !isNaN(n));
      
      let nextNum = existingCodes.length > 0 ? Math.max(...existingCodes) + 1 : 1;
      
      const newAssets = [];
      for (let i = 0; i < batchQuantity; i++) {
        const assetCode = `${config.prefix}-${year}-${nextNum.toString().padStart(3, '0')}`;
        const serialNumber = autoGenerateSerial 
          ? `${config.prefix}-SN-${Date.now()}-${i + 1}`
          : '';
        
        const assetData = {
          ...formData,
          code: assetCode,
          serialNumber: formData.serialNumber || serialNumber,
          monthlyDepreciation,
          status: 'active',
          createdAt: new Date().toISOString(),
          batchId,
          batchIndex: i + 1,
          batchTotal: batchQuantity,
        };
        
        newAssets.push(assetData);
        nextNum++;
      }
      
      // Save all assets
      localStorage.setItem('assets', JSON.stringify([...existingAssets, ...newAssets]));
      
      toast.success(`Đã tạo thành công ${batchQuantity} tài sản!`, {
        description: `Mã từ ${newAssets[0].code} đến ${newAssets[newAssets.length - 1].code}`,
      });
      
      // Navigate to batch view
      navigate('/assets/batch');
    } else {
      // Single mode: Create one asset
      const submitData = {
        ...formData,
        code: previewCode,
        monthlyDepreciation,
        status: 'active',
        createdAt: new Date().toISOString(),
        batchId: null,
      };
      
      localStorage.setItem('assets', JSON.stringify([...existingAssets, submitData]));
      toast.success('Đã thêm tài sản thành công!');
      navigate('/assets');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(value);
  };

  const selectedGroupConfig = formData.assetGroup 
    ? assetGroupConfig[formData.assetGroup as keyof typeof assetGroupConfig]
    : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-gray-900">
            {isEdit ? 'Chỉnh sửa Tài sản' : 'Thêm Tài sản mới'}
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            {isEdit ? 'Cập nhật thông tin tài sản' : 'Nhập thông tin tài sản cố định'}
          </p>
        </div>
        <button
          onClick={() => navigate('/assets')}
          className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <X className="w-5 h-5" />
          Hủy
        </button>
      </div>

      {/* Batch Mode Toggle */}
      {!isEdit && (
        <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <Layers className="w-5 h-5 text-purple-600 mt-0.5" />
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-purple-900 font-medium">Thêm tài sản theo lô</p>
                  <p className="text-sm text-purple-700 mt-1">
                    Bật chế độ này để thêm nhiều tài sản cùng loại một lúc. Mỗi tài sản sẽ có mã riêng và được quản lý độc lập.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer ml-4">
                  <input
                    type="checkbox"
                    checked={isBatchMode}
                    onChange={(e) => {
                      setIsBatchMode(e.target.checked);
                      if (!e.target.checked) {
                        setBatchQuantity(1);
                      }
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Info Box */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
        <div className="flex-1">
          <p className="text-sm text-blue-900 font-medium">Lưu ý khi thêm tài sản</p>
          <p className="text-sm text-blue-700 mt-1">
            {isBatchMode 
              ? 'Hệ thống sẽ tự động tạo nhiều tài sản với mã liên tiếp. Mỗi tài sản sẽ có đầy đủ chức năng quản lý riêng.'
              : 'Mã tài sản sẽ được tự động tạo dựa trên nhóm tài sản. Hệ thống sẽ tự động sinh chứng từ ghi tăng tài sản và bắt đầu tính khấu hao từ tháng tiếp theo.'
            }
          </p>
        </div>
      </div>

      {/* Preview Asset Code */}
      {previewCode && !isEdit && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start gap-3">
          <Info className="w-5 h-5 text-green-600 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm text-green-900 font-medium">
              {isBatchMode ? 'Mã tài sản dự kiến (Mã đầu tiên)' : 'Mã tài sản dự kiến'}
            </p>
            <p className="text-lg font-bold text-green-700 mt-1">{previewCode}</p>
            {isBatchMode && batchQuantity > 1 && (
              <p className="text-sm text-green-600 mt-1">
                Sẽ tạo {batchQuantity} tài sản với mã từ {previewCode} đến {
                  (() => {
                    const parts = previewCode.split('-');
                    const num = parseInt(parts[2]) + batchQuantity - 1;
                    return `${parts[0]}-${parts[1]}-${num.toString().padStart(3, '0')}`;
                  })()
                }
              </p>
            )}
          </div>
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Batch Quantity - Only show in batch mode */}
        {isBatchMode && (
          <div className="bg-white rounded-lg border border-purple-300 p-6 shadow-sm">
            <h3 className="font-semibold text-purple-900 mb-4 flex items-center gap-2">
              <Layers className="w-5 h-5" />
              Cài đặt Lô
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Số lượng tài sản <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  value={batchQuantity}
                  onChange={(e) => setBatchQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  min="1"
                  max="1000"
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Nhập số lượng"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Hệ thống sẽ tạo {batchQuantity} tài sản riêng biệt
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Serial Number
                </label>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoGenerateSerial}
                      onChange={(e) => setAutoGenerateSerial(e.target.checked)}
                      className="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
                    />
                    <span className="text-sm text-gray-700">Tự động sinh Serial Number</span>
                  </label>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {autoGenerateSerial 
                    ? 'Mỗi tài sản sẽ có serial number riêng'
                    : 'Serial number sẽ được để trống, có thể cập nhật sau'
                  }
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Basic Information */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Thông tin cơ bản</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nhóm tài sản <span className="text-red-500">*</span>
              </label>
              <select
                name="assetGroup"
                value={formData.assetGroup}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">-- Chọn nhóm tài sản --</option>
                {Object.entries(assetGroupConfig).map(([key, config]) => (
                  <option key={key} value={key}>
                    {config.name} ({config.prefix}-XXXX-XXX)
                  </option>
                ))}
              </select>
              {selectedGroupConfig && (
                <p className="text-xs text-gray-500 mt-1">
                  Mã prefix: {selectedGroupConfig.prefix} • Khấu hao mặc định: {selectedGroupConfig.defaultDepreciationPeriod} tháng
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tên tài sản <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="VD: MacBook Pro 16 inch M3 Max"
              />
            </div>

            {!(isBatchMode && autoGenerateSerial) && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Serial Number {isBatchMode && '(Dùng chung cho tất cả)'}
                </label>
                <input
                  type="text"
                  name="serialNumber"
                  value={formData.serialNumber}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder={isBatchMode ? "Để trống nếu mỗi tài sản khác nhau" : "Nhập số serial"}
                />
                {isBatchMode && !autoGenerateSerial && (
                  <p className="text-xs text-gray-500 mt-1">
                    Nếu nhập, tất cả tài sản trong lô sẽ có cùng serial. Có thể để trống và cập nhật sau.
                  </p>
                )}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nhà sản xuất
              </label>
              <input
                type="text"
                name="manufacturer"
                value={formData.manufacturer}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="VD: Apple, Dell, HP..."
              />
            </div>
          </div>

          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Mô tả
            </label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={3}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Mô tả chi tiết về tài sản..."
            />
          </div>
        </div>

        {/* Technical Specifications */}
        {selectedGroupConfig && selectedGroupConfig.fields.length > 0 && (
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Thông số kỹ thuật</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {selectedGroupConfig.fields.includes('cpu') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">CPU/Processor</label>
                  <input
                    type="text"
                    name="cpu"
                    value={formData.cpu}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="VD: Intel Core i7-13700K"
                  />
                </div>
              )}

              {selectedGroupConfig.fields.includes('ram') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">RAM</label>
                  <input
                    type="text"
                    name="ram"
                    value={formData.ram}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="VD: 32GB DDR5"
                  />
                </div>
              )}

              {selectedGroupConfig.fields.includes('storage') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Storage/Ổ cứng</label>
                  <input
                    type="text"
                    name="storage"
                    value={formData.storage}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="VD: 1TB NVMe SSD"
                  />
                </div>
              )}

              {selectedGroupConfig.fields.includes('display') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Màn hình</label>
                  <input
                    type="text"
                    name="display"
                    value={formData.display}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="VD: 16 inch Retina"
                  />
                </div>
              )}

              {selectedGroupConfig.fields.includes('raid') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Cấu hình RAID</label>
                  <input
                    type="text"
                    name="raid"
                    value={formData.raid}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="VD: RAID 5"
                  />
                </div>
              )}

              {selectedGroupConfig.fields.includes('size') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Kích thước</label>
                  <input
                    type="text"
                    name="size"
                    value={formData.size}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="VD: 27 inch"
                  />
                </div>
              )}

              {selectedGroupConfig.fields.includes('resolution') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Độ phân giải</label>
                  <input
                    type="text"
                    name="resolution"
                    value={formData.resolution}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="VD: 2560x1440"
                  />
                </div>
              )}

              {selectedGroupConfig.fields.includes('printType') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Loại máy in</label>
                  <select
                    name="printType"
                    value={formData.printType}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Chọn loại</option>
                    <option value="laser">Laser</option>
                    <option value="inkjet">Inkjet</option>
                    <option value="thermal">Thermal</option>
                  </select>
                </div>
              )}

              {selectedGroupConfig.fields.includes('speed') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Tốc độ</label>
                  <input
                    type="text"
                    name="speed"
                    value={formData.speed}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="VD: 30 ppm hoặc 1Gbps"
                  />
                </div>
              )}

              {selectedGroupConfig.fields.includes('ports') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Số cổng</label>
                  <input
                    type="text"
                    name="ports"
                    value={formData.ports}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="VD: 24 ports"
                  />
                </div>
              )}

              {selectedGroupConfig.fields.includes('material') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Chất liệu</label>
                  <input
                    type="text"
                    name="material"
                    value={formData.material}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="VD: Gỗ công nghiệp"
                  />
                </div>
              )}

              {selectedGroupConfig.fields.includes('dimensions') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Kích thước (cm)</label>
                  <input
                    type="text"
                    name="dimensions"
                    value={formData.dimensions}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="VD: 120 x 60 x 75"
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {/* Accounting Information */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Calculator className="w-5 h-5 text-blue-600" />
            Thông tin kế toán
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ngày mua/Ngày ghi tăng <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                name="purchaseDate"
                value={formData.purchaseDate}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nguyên giá (VNĐ) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                name="originalValue"
                value={formData.originalValue}
                onChange={handleChange}
                required
                min="0"
                step="1000"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tài khoản hạch toán <span className="text-red-500">*</span>
              </label>
              <select
                name="accountCode"
                value={formData.accountCode}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">-- Chọn tài khoản --</option>
                <option value="2111">2111 - Máy móc thiết bị</option>
                <option value="2112">2112 - Thiết bị văn phòng</option>
                <option value="2113">2113 - Thiết bị công nghệ</option>
                <option value="2114">2114 - Phương tiện vận tải</option>
              </select>
              {selectedGroupConfig && (
                <p className="text-xs text-gray-500 mt-1">
                  Gợi ý: {selectedGroupConfig.accountName}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Phương pháp khấu hao <span className="text-red-500">*</span>
              </label>
              <select
                name="depreciationMethod"
                value={formData.depreciationMethod}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="straight-line">Khấu hao đường thẳng</option>
                <option value="declining-balance">Khấu hao số dư giảm dần</option>
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Thời gian khấu hao (tháng) <span className="text-red-500">*</span>
              </label>
              <div className="flex gap-4">
                <input
                  type="number"
                  name="depreciationPeriod"
                  value={formData.depreciationPeriod}
                  onChange={handleChange}
                  required
                  min="1"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="VD: 36, 48, 60..."
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, depreciationPeriod: '36' }))}
                    className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-sm"
                  >
                    36
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, depreciationPeriod: '48' }))}
                    className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-sm"
                  >
                    48
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, depreciationPeriod: '60' }))}
                    className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-sm"
                  >
                    60
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Depreciation Preview */}
          {monthlyDepreciation > 0 && (
            <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Dự kiến Khấu hao</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-blue-700">Khấu hao hàng tháng</p>
                  <p className="font-bold text-blue-900">{formatCurrency(monthlyDepreciation)}</p>
                </div>
                <div>
                  <p className="text-blue-700">Khấu hao hàng năm</p>
                  <p className="font-bold text-blue-900">{formatCurrency(monthlyDepreciation * 12)}</p>
                </div>
                <div>
                  <p className="text-blue-700">Giá trị còn lại (sau {formData.depreciationPeriod} tháng)</p>
                  <p className="font-bold text-blue-900">
                    {formData.depreciationMethod === 'straight-line' 
                      ? formatCurrency(0)
                      : formatCurrency(parseFloat(formData.originalValue || '0') * 0.1)
                    }
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Assignment Information */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Thông tin cấp phát & Vị trí</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Phòng ban sử dụng <span className="text-red-500">*</span>
              </label>
              <select
                name="department"
                value={formData.department}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">-- Chọn phòng ban --</option>
                <option value="it">IT Department</option>
                <option value="tech">Kỹ thuật</option>
                <option value="sales">Sales</option>
                <option value="marketing">Marketing</option>
                <option value="admin">Admin</option>
                <option value="hr">Human Resources</option>
                <option value="finance">Tài chính Kế toán</option>
                <option value="warehouse">Kho</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Người nhận/Người sử dụng
              </label>
              <input
                type="text"
                name="recipient"
                value={formData.recipient}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Tên người nhận tài sản"
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-4">
          <button
            type="button"
            onClick={() => navigate('/assets')}
            className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Hủy
          </button>
          <button
            type="submit"
            className={`flex items-center gap-2 px-6 py-2 text-white rounded-lg transition-colors ${
              isBatchMode 
                ? 'bg-purple-600 hover:bg-purple-700' 
                : 'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            {isBatchMode ? <Layers className="w-5 h-5" /> : <Save className="w-5 h-5" />}
            {isEdit 
              ? 'Cập nhật' 
              : isBatchMode 
                ? `Tạo Lô ${batchQuantity} Tài sản` 
                : 'Lưu Tài sản'
            }
          </button>
        </div>
      </form>
    </div>
  );
}
