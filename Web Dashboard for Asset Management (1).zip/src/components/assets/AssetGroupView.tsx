import { useState } from 'react';
import { Link } from 'react-router';
import { Package, ChevronDown, ChevronRight, Plus, Eye, ArrowLeft, List } from 'lucide-react';

// Cấu hình nhóm tài sản - sync với AssetForm
const assetGroupConfig = {
  laptop: { name: 'Laptop', prefix: 'LAP', color: 'bg-blue-100 text-blue-700' },
  desktop: { name: 'Desktop/PC', prefix: 'DES', color: 'bg-green-100 text-green-700' },
  server: { name: 'Server', prefix: 'SRV', color: 'bg-red-100 text-red-700' },
  monitor: { name: 'Màn hình', prefix: 'MON', color: 'bg-purple-100 text-purple-700' },
  printer: { name: 'Máy in', prefix: 'PRT', color: 'bg-yellow-100 text-yellow-700' },
  network: { name: 'Thiết bị mạng', prefix: 'NET', color: 'bg-indigo-100 text-indigo-700' },
  furniture: { name: 'Nội thất văn phòng', prefix: 'FUR', color: 'bg-orange-100 text-orange-700' },
  other: { name: 'Khác', prefix: 'OTH', color: 'bg-gray-100 text-gray-700' }
};

interface Asset {
  id: string;
  code: string;
  name: string;
  group: keyof typeof assetGroupConfig;
  department: string;
  user: string;
  originalValue: number;
  remainingValue: number;
  status: string;
}

// Mock data grouped by asset group
const mockAssetsGrouped: Record<keyof typeof assetGroupConfig, Asset[]> = {
  laptop: [
    {
      id: '1',
      code: 'LAP-2024-001',
      name: 'MacBook Pro 16" M3 Max',
      group: 'laptop',
      department: 'IT',
      user: 'Nguyễn Văn A',
      originalValue: 85000000,
      remainingValue: 72000000,
      status: 'active'
    },
    {
      id: '2',
      code: 'LAP-2024-002',
      name: 'Dell XPS 15',
      group: 'laptop',
      department: 'Marketing',
      user: 'Trần Thị B',
      originalValue: 45000000,
      remainingValue: 38000000,
      status: 'active'
    },
    {
      id: '3',
      code: 'LAP-2023-045',
      name: 'Lenovo ThinkPad X1',
      group: 'laptop',
      department: 'Sales',
      user: 'Lê Văn C',
      originalValue: 35000000,
      remainingValue: 22000000,
      status: 'active'
    }
  ],
  desktop: [
    {
      id: '10',
      code: 'DES-2024-005',
      name: 'Dell Optiplex 7090',
      group: 'desktop',
      department: 'Admin',
      user: 'Phạm Văn D',
      originalValue: 22000000,
      remainingValue: 18000000,
      status: 'active'
    }
  ],
  server: [
    {
      id: '20',
      code: 'SRV-2024-001',
      name: 'Dell PowerEdge R740',
      group: 'server',
      department: 'IT',
      user: 'Server Room',
      originalValue: 180000000,
      remainingValue: 165000000,
      status: 'active'
    },
    {
      id: '21',
      code: 'SRV-2023-012',
      name: 'HP ProLiant DL380',
      group: 'server',
      department: 'IT',
      user: 'Server Room',
      originalValue: 150000000,
      remainingValue: 120000000,
      status: 'active'
    }
  ],
  monitor: [
    {
      id: '30',
      code: 'MON-2024-023',
      name: 'Dell UltraSharp 27" 4K',
      group: 'monitor',
      department: 'Design',
      user: 'Hoàng Văn E',
      originalValue: 12000000,
      remainingValue: 9500000,
      status: 'active'
    }
  ],
  printer: [
    {
      id: '40',
      code: 'PRT-2023-008',
      name: 'HP LaserJet Pro M404dn',
      group: 'printer',
      department: 'Admin',
      user: 'Shared',
      originalValue: 8500000,
      remainingValue: 6000000,
      status: 'active'
    }
  ],
  network: [
    {
      id: '50',
      code: 'NET-2024-002',
      name: 'Cisco Catalyst 2960X',
      group: 'network',
      department: 'IT',
      user: 'Network Room',
      originalValue: 35000000,
      remainingValue: 32000000,
      status: 'active'
    }
  ],
  furniture: [],
  other: []
};

const statusConfig: Record<string, { label: string; color: string }> = {
  active: { label: 'Đang sử dụng', color: 'bg-green-100 text-green-700' },
  maintenance: { label: 'Bảo trì', color: 'bg-yellow-100 text-yellow-700' },
  idle: { label: 'Chờ cấp phát', color: 'bg-gray-100 text-gray-700' },
  liquidated: { label: 'Đã thanh lý', color: 'bg-red-100 text-red-700' }
};

export function AssetGroupView() {
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set(['laptop', 'server']));

  const toggleGroup = (group: string) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(group)) {
      newExpanded.delete(group);
    } else {
      newExpanded.add(group);
    }
    setExpandedGroups(newExpanded);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(value);
  };

  const getGroupTotal = (assets: Asset[]) => {
    return assets.reduce((sum, asset) => sum + asset.originalValue, 0);
  };

  const getTotalAssets = () => {
    return Object.values(mockAssetsGrouped).reduce((sum, assets) => sum + assets.length, 0);
  };

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm">
        <Link to="/assets" className="text-blue-600 hover:text-blue-700 flex items-center gap-1">
          <ArrowLeft className="w-4 h-4" />
          Danh sách
        </Link>
        <span className="text-gray-400">/</span>
        <span className="text-gray-900 font-medium">Xem theo Nhóm</span>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-gray-900">Quản lý Tài sản theo Nhóm</h1>
          <p className="text-sm text-gray-500 mt-1">
            Tổng số: {getTotalAssets()} tài sản được phân loại trong {Object.keys(assetGroupConfig).length} nhóm
          </p>
        </div>
        <div className="flex gap-3">
          <Link
            to="/assets"
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <List className="w-5 h-5" />
            Xem Danh sách
          </Link>
          <Link
            to="/assets/new"
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            Thêm Tài sản
          </Link>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {Object.entries(assetGroupConfig).slice(0, 4).map(([key, config]) => {
          const assets = mockAssetsGrouped[key as keyof typeof assetGroupConfig];
          return (
            <div key={key} className="bg-white rounded-lg border border-gray-200 p-4">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${config.color}`}>
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">{config.name}</p>
                  <p className="font-bold text-gray-900">{assets.length}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Grouped Assets */}
      <div className="space-y-4">
        {Object.entries(assetGroupConfig).map(([groupKey, groupConfig]) => {
          const assets = mockAssetsGrouped[groupKey as keyof typeof assetGroupConfig];
          const isExpanded = expandedGroups.has(groupKey);

          if (assets.length === 0) return null;

          return (
            <div key={groupKey} className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              {/* Group Header */}
              <button
                onClick={() => toggleGroup(groupKey)}
                className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  {isExpanded ? (
                    <ChevronDown className="w-5 h-5 text-gray-500" />
                  ) : (
                    <ChevronRight className="w-5 h-5 text-gray-500" />
                  )}
                  <div className={`p-2 rounded-lg ${groupConfig.color}`}>
                    <Package className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <h3 className="font-semibold text-gray-900">{groupConfig.name}</h3>
                    <p className="text-sm text-gray-500">
                      {assets.length} tài sản • Tổng giá trị: {formatCurrency(getGroupTotal(assets))}
                    </p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${groupConfig.color}`}>
                  {groupConfig.prefix}-*
                </span>
              </button>

              {/* Group Content */}
              {isExpanded && (
                <div className="border-t border-gray-200">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Mã TS
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Tên tài sản
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Phòng ban
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Người dùng
                          </th>
                          <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Nguyên giá
                          </th>
                          <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Giá trị còn lại
                          </th>
                          <th className="px-6 py-3 text-center text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Trạng thái
                          </th>
                          <th className="px-6 py-3 text-center text-xs font-medium text-gray-700 uppercase tracking-wider">
                            Thao tác
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {assets.map((asset) => (
                          <tr key={asset.id} className="hover:bg-gray-50 transition-colors">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="text-sm font-medium text-blue-600">{asset.code}</span>
                            </td>
                            <td className="px-6 py-4">
                              <span className="text-sm text-gray-900">{asset.name}</span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="text-sm text-gray-600">{asset.department}</span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="text-sm text-gray-600">{asset.user}</span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right">
                              <span className="text-sm text-gray-900">{formatCurrency(asset.originalValue)}</span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right">
                              <span className="text-sm font-medium text-gray-900">{formatCurrency(asset.remainingValue)}</span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-center">
                              <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${statusConfig[asset.status].color}`}>
                                {statusConfig[asset.status].label}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center justify-center gap-2">
                                <Link
                                  to={`/assets/${asset.id}`}
                                  className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                                  title="Chi tiết"
                                >
                                  <Eye className="w-4 h-4" />
                                </Link>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
