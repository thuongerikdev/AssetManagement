import { Link, useParams, useNavigate } from 'react-router';
import { ArrowLeft, Edit, Send, ArrowLeftRight, Trash2, FileText, Clock } from 'lucide-react';

export function AssetDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  // Mock data
  const asset = {
    id: id,
    code: 'LAP-001',
    name: 'MacBook Pro 16" M3 Max',
    type: 'Laptop',
    group: 'Thiết bị công nghệ',
    status: 'active',
    serialNumber: 'C02XY1234567',
    manufacturer: 'Apple',
    purchaseDate: '2024-01-15',
    originalValue: 85000000,
    remainingValue: 68000000,
    accumulatedDepreciation: 17000000,
    depreciationPeriod: 36,
    monthlyDepreciation: 2361111,
    accountCode: '2113',
    department: 'IT',
    user: 'Nguyễn Văn A',
    assignedDate: '2024-01-20',
    description: 'MacBook Pro 16 inch với chip M3 Max, 36GB RAM, 1TB SSD',
  };

  const history = [
    { id: 1, date: '2024-01-20', type: 'Cấp phát', user: 'Nguyễn Văn A', department: 'IT', note: 'Cấp phát ban đầu' },
    { id: 2, date: '2024-06-15', type: 'Bảo trì', user: 'Nguyễn Văn A', department: 'IT', note: 'Thay pin' },
    { id: 3, date: '2025-01-10', type: 'Bảo trì', user: 'Nguyễn Văn A', department: 'IT', note: 'Nâng cấp RAM' },
  ];

  const vouchers = [
    { id: 1, code: 'CT-2024-001', date: '2024-01-15', type: 'Ghi tăng TSCĐ', amount: 85000000, status: 'Đã ghi sổ' },
    { id: 2, code: 'CT-2024-045', date: '2024-02-01', type: 'Khấu hao', amount: 2361111, status: 'Đã ghi sổ' },
    { id: 3, code: 'CT-2024-089', date: '2024-03-01', type: 'Khấu hao', amount: 2361111, status: 'Đã ghi sổ' },
  ];

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(value);
  };

  const statusConfig = {
    active: { label: 'Đang sử dụng', color: 'bg-green-100 text-green-700' },
    maintenance: { label: 'Bảo trì', color: 'bg-orange-100 text-orange-700' },
    liquidated: { label: 'Đã thanh lý', color: 'bg-gray-100 text-gray-700' },
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/assets')}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-bold text-gray-900">Chi tiết Tài sản</h1>
            <p className="text-sm text-gray-500 mt-1">Mã: {asset.code}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Link
            to={`/assets/${id}/edit`}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Edit className="w-4 h-4" />
            Chỉnh sửa
          </Link>
          <button className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            <Send className="w-4 h-4" />
            Cấp phát
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
            <ArrowLeftRight className="w-4 h-4" />
            Điều chuyển
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
            <Trash2 className="w-4 h-4" />
            Thanh lý
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Info */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">Thông tin cơ bản</h3>
              <span className={`inline-flex px-3 py-1 text-xs font-medium rounded-full ${statusConfig[asset.status as keyof typeof statusConfig].color}`}>
                {statusConfig[asset.status as keyof typeof statusConfig].label}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600 mb-1">Tên tài sản</p>
                <p className="text-sm font-medium text-gray-900">{asset.name}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Loại tài sản</p>
                <p className="text-sm font-medium text-gray-900">{asset.type}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Nhóm tài sản</p>
                <p className="text-sm font-medium text-gray-900">{asset.group}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Serial Number</p>
                <p className="text-sm font-medium text-gray-900">{asset.serialNumber}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Nhà sản xuất</p>
                <p className="text-sm font-medium text-gray-900">{asset.manufacturer}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Ngày mua</p>
                <p className="text-sm font-medium text-gray-900">{new Date(asset.purchaseDate).toLocaleDateString('vi-VN')}</p>
              </div>
              <div className="col-span-2">
                <p className="text-sm text-gray-600 mb-1">Mô tả</p>
                <p className="text-sm font-medium text-gray-900">{asset.description}</p>
              </div>
            </div>
          </div>

          {/* Accounting Info */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Thông tin kế toán</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600 mb-1">Nguyên giá</p>
                <p className="text-lg font-bold text-gray-900">{formatCurrency(asset.originalValue)}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Giá trị còn lại</p>
                <p className="text-lg font-bold text-green-600">{formatCurrency(asset.remainingValue)}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Khấu hao lũy kế</p>
                <p className="text-sm font-medium text-gray-900">{formatCurrency(asset.accumulatedDepreciation)}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Khấu hao/tháng</p>
                <p className="text-sm font-medium text-gray-900">{formatCurrency(asset.monthlyDepreciation)}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Thời gian KH</p>
                <p className="text-sm font-medium text-gray-900">{asset.depreciationPeriod} tháng</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Tài khoản</p>
                <p className="text-sm font-medium text-gray-900">{asset.accountCode}</p>
              </div>
            </div>
          </div>

          {/* Usage History */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Lịch sử sử dụng
            </h3>
            <div className="space-y-3">
              {history.map((item) => (
                <div key={item.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-medium text-gray-900">{item.type}</span>
                      <span className="text-xs text-gray-500">•</span>
                      <span className="text-xs text-gray-500">{new Date(item.date).toLocaleDateString('vi-VN')}</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      {item.user} - {item.department}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">{item.note}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Vouchers */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Chứng từ liên quan
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-700">Số CT</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-700">Ngày</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-700">Loại</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-700">Số tiền</th>
                    <th className="px-4 py-2 text-center text-xs font-medium text-gray-700">Trạng thái</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {vouchers.map((voucher) => (
                    <tr key={voucher.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <Link to={`/vouchers/${voucher.id}`} className="text-sm text-blue-600 hover:underline">
                          {voucher.code}
                        </Link>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {new Date(voucher.date).toLocaleDateString('vi-VN')}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-900">{voucher.type}</td>
                      <td className="px-4 py-3 text-sm text-gray-900 text-right">{formatCurrency(voucher.amount)}</td>
                      <td className="px-4 py-3 text-center">
                        <span className="inline-flex px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-700">
                          {voucher.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Current Assignment */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Thông tin cấp phát</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 mb-1">Phòng ban</p>
                <p className="text-sm font-medium text-gray-900">{asset.department}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Người sử dụng</p>
                <p className="text-sm font-medium text-gray-900">{asset.user}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Ngày cấp phát</p>
                <p className="text-sm font-medium text-gray-900">
                  {new Date(asset.assignedDate).toLocaleDateString('vi-VN')}
                </p>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg p-6 text-white">
            <h3 className="font-semibold mb-4">Tỷ lệ khấu hao</h3>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Đã khấu hao</span>
                  <span>20%</span>
                </div>
                <div className="w-full bg-blue-700 rounded-full h-2">
                  <div className="bg-white rounded-full h-2" style={{ width: '20%' }}></div>
                </div>
              </div>
              <p className="text-xs opacity-90">
                Còn {asset.depreciationPeriod - Math.floor(asset.depreciationPeriod * 0.2)} tháng khấu hao
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
