import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Save, X, AlertCircle } from 'lucide-react';

export function MaintenanceForm() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    assetId: '',
    date: '',
    type: '',
    description: '',
    hasCost: false,
    cost: '',
    costType: '',
    vendor: '',
    note: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Saving maintenance:', formData);
    navigate('/maintenance');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-gray-900">Tạo Phiếu bảo trì</h1>
          <p className="text-sm text-gray-500 mt-1">Ghi nhận bảo trì và chi phí phát sinh</p>
        </div>
        <button
          onClick={() => navigate('/maintenance')}
          className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <X className="w-5 h-5" />
          Hủy
        </button>
      </div>

      {/* Info Alert */}
      <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
        <div className="flex-1">
          <p className="text-sm text-orange-900 font-medium">Logic hệ thống</p>
          <ul className="text-sm text-orange-700 mt-2 space-y-1 list-disc list-inside">
            <li>Nếu có chi phí → Bắt buộc chọn loại chi phí</li>
            <li>Chi phí sửa chữa → Hệ thống sinh chứng từ chi phí</li>
            <li>Nâng cấp tài sản → Tăng nguyên giá tài sản và tính lại khấu hao</li>
          </ul>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Asset Selection */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Thông tin tài sản</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Chọn tài sản <span className="text-red-500">*</span>
              </label>
              <select
                name="assetId"
                value={formData.assetId}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">-- Chọn tài sản cần bảo trì --</option>
                <option value="1">LAP-001 - MacBook Pro 16" M3 Max</option>
                <option value="2">SRV-001 - Dell PowerEdge R740</option>
                <option value="3">LAP-012 - Dell XPS 15</option>
                <option value="4">PRT-008 - HP LaserJet Pro M404</option>
                <option value="5">MON-045 - LG UltraWide 34"</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ngày bảo trì <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Loại bảo trì <span className="text-red-500">*</span>
              </label>
              <select
                name="type"
                value={formData.type}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Chọn loại</option>
                <option value="periodic">Bảo trì định kỳ</option>
                <option value="repair">Sửa chữa</option>
                <option value="upgrade">Nâng cấp</option>
                <option value="cleaning">Vệ sinh</option>
                <option value="inspection">Kiểm tra</option>
              </select>
            </div>
          </div>

          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nội dung bảo trì <span className="text-red-500">*</span>
            </label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              required
              rows={3}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Mô tả chi tiết về công việc bảo trì..."
            />
          </div>
        </div>

        {/* Cost Information */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Thông tin chi phí</h3>
          
          <div className="mb-4">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                name="hasCost"
                checked={formData.hasCost}
                onChange={handleChange}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm font-medium text-gray-700">
                Có phát sinh chi phí
              </span>
            </label>
          </div>

          {formData.hasCost && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-gray-200">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Chi phí phát sinh (VNĐ) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="cost"
                  value={formData.cost}
                  onChange={handleChange}
                  required={formData.hasCost}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Loại chi phí <span className="text-red-500">*</span>
                </label>
                <select
                  name="costType"
                  value={formData.costType}
                  onChange={handleChange}
                  required={formData.hasCost}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Chọn loại chi phí</option>
                  <option value="repair">Chi phí sửa chữa (hạch toán chi phí)</option>
                  <option value="upgrade">Nâng cấp tài sản (tăng nguyên giá)</option>
                </select>
              </div>

              {formData.costType && (
                <div className="md:col-span-2 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-900 font-medium mb-1">
                    {formData.costType === 'repair' ? '📝 Chi phí sửa chữa' : '⬆️ Nâng cấp tài sản'}
                  </p>
                  <p className="text-sm text-blue-700">
                    {formData.costType === 'repair' 
                      ? 'Hệ thống sẽ tự động ghi nhận vào chi phí (TK 627) và sinh chứng từ kế toán'
                      : 'Hệ thống sẽ tự động tăng nguyên giá tài sản và tính lại khấu hao'}
                  </p>
                </div>
              )}

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nhà cung cấp / Đơn vị bảo trì
                </label>
                <input
                  type="text"
                  name="vendor"
                  value={formData.vendor}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="VD: Dell Vietnam, Apple Authorized..."
                />
              </div>
            </div>
          )}
        </div>

        {/* Additional Information */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Thông tin bổ sung</h3>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Ghi chú
            </label>
            <textarea
              name="note"
              value={formData.note}
              onChange={handleChange}
              rows={3}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Các ghi chú khác..."
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-4">
          <button
            type="button"
            onClick={() => navigate('/maintenance')}
            className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Hủy
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
          >
            <Save className="w-5 h-5" />
            Lưu Phiếu bảo trì
          </button>
        </div>
      </form>
    </div>
  );
}
