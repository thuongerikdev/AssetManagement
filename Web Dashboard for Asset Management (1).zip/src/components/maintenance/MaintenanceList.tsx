import { useState } from 'react';
import { Link } from 'react-router';
import { Plus, Search, Filter, Wrench, Calendar } from 'lucide-react';

interface MaintenanceRecord {
  id: string;
  date: string;
  asset: { code: string; name: string };
  type: string;
  cost: number;
  costType: 'repair' | 'upgrade';
  status: 'pending' | 'inProgress' | 'completed';
  vendor: string;
  note: string;
}

const mockRecords: MaintenanceRecord[] = [
  {
    id: '1',
    date: '2026-02-10',
    asset: { code: 'LAP-012', name: 'Dell XPS 15' },
    type: 'Thay pin',
    cost: 5000000,
    costType: 'repair',
    status: 'completed',
    vendor: 'Dell Vietnam',
    note: 'Pin chai, thay mới'
  },
  {
    id: '2',
    date: '2026-01-25',
    asset: { code: 'LAP-001', name: 'MacBook Pro 16"' },
    type: 'Nâng cấp RAM',
    cost: 15000000,
    costType: 'upgrade',
    status: 'completed',
    vendor: 'Apple Authorized',
    note: 'Nâng cấp từ 32GB lên 64GB RAM'
  },
  {
    id: '3',
    date: '2026-02-15',
    asset: { code: 'SRV-001', name: 'Dell PowerEdge R740' },
    type: 'Bảo trì định kỳ',
    cost: 8000000,
    costType: 'repair',
    status: 'inProgress',
    vendor: 'Dell EMC',
    note: 'Bảo trì 6 tháng/lần'
  },
  {
    id: '4',
    date: '2026-02-20',
    asset: { code: 'PRT-008', name: 'HP LaserJet Pro' },
    type: 'Vệ sinh máy',
    cost: 1500000,
    costType: 'repair',
    status: 'pending',
    vendor: 'HP Service Center',
    note: 'Vệ sinh và thay mực'
  },
];

const statusConfig = {
  pending: { label: 'Chờ xử lý', color: 'bg-yellow-100 text-yellow-700' },
  inProgress: { label: 'Đang thực hiện', color: 'bg-blue-100 text-blue-700' },
  completed: { label: 'Hoàn thành', color: 'bg-green-100 text-green-700' },
};

const costTypeConfig = {
  repair: { label: 'Sửa chữa', color: 'text-orange-600' },
  upgrade: { label: 'Nâng cấp', color: 'text-blue-600' },
};

export function MaintenanceList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredRecords = mockRecords.filter(record => {
    const matchesSearch = record.asset.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.asset.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || record.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-gray-900">Bảo trì - Bảo dưỡng</h1>
          <p className="text-sm text-gray-500 mt-1">Quản lý bảo trì và sửa chữa tài sản</p>
        </div>
        <Link
          to="/maintenance/new"
          className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Tạo Phiếu bảo trì
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-orange-100 rounded-lg">
              <Wrench className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Tổng chi phí tháng này</p>
              <p className="font-bold text-gray-900">68 triệu VNĐ</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Calendar className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Sắp đến hạn bảo trì</p>
              <p className="font-bold text-gray-900">15 tài sản</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-100 rounded-lg">
              <Wrench className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Hoàn thành</p>
              <p className="font-bold text-gray-900">23 phiếu</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Tìm kiếm theo mã hoặc tên tài sản..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="pending">Chờ xử lý</option>
              <option value="inProgress">Đang thực hiện</option>
              <option value="completed">Hoàn thành</option>
            </select>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-5 h-5" />
              Bộ lọc
            </button>
          </div>
        </div>
      </div>

      {/* Maintenance Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Ngày
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Tài sản
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Loại bảo trì
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Loại chi phí
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Chi phí
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Nhà cung cấp
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Trạng thái
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredRecords.map((record) => (
                <tr key={record.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-900">
                      {new Date(record.date).toLocaleDateString('vi-VN')}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-sm font-medium text-blue-600">{record.asset.code}</p>
                      <p className="text-sm text-gray-600">{record.asset.name}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-900">{record.type}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`text-sm font-medium ${costTypeConfig[record.costType].color}`}>
                      {costTypeConfig[record.costType].label}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className="text-sm font-medium text-gray-900">
                      {formatCurrency(record.cost)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-600">{record.vendor}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${statusConfig[record.status].color}`}>
                      {statusConfig[record.status].label}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
