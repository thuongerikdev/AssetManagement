import { useState } from 'react';
import { Calculator, FileText, Download, AlertCircle } from 'lucide-react';

interface DepreciationAsset {
  id: string;
  code: string;
  name: string;
  department: string;
  originalValue: number;
  accumulatedDepreciation: number;
  monthlyDepreciation: number;
  remainingValue: number;
  selected: boolean;
}

export function DepreciationList() {
  const [selectedMonth, setSelectedMonth] = useState('2026-02');
  const [showVoucher, setShowVoucher] = useState(false);

  const [assets, setAssets] = useState<DepreciationAsset[]>([
    {
      id: '1',
      code: 'LAP-001',
      name: 'MacBook Pro 16" M3 Max',
      department: 'IT',
      originalValue: 85000000,
      accumulatedDepreciation: 17000000,
      monthlyDepreciation: 2361111,
      remainingValue: 68000000,
      selected: true,
    },
    {
      id: '2',
      code: 'SRV-001',
      name: 'Dell PowerEdge R740',
      department: 'IT',
      originalValue: 250000000,
      accumulatedDepreciation: 50000000,
      monthlyDepreciation: 4166667,
      remainingValue: 200000000,
      selected: true,
    },
    {
      id: '3',
      code: 'MON-045',
      name: 'LG UltraWide 34"',
      department: 'Marketing',
      originalValue: 15000000,
      accumulatedDepreciation: 6000000,
      monthlyDepreciation: 416667,
      remainingValue: 9000000,
      selected: true,
    },
    {
      id: '4',
      code: 'LAP-012',
      name: 'Dell XPS 15',
      department: 'Sales',
      originalValue: 45000000,
      accumulatedDepreciation: 22500000,
      monthlyDepreciation: 1250000,
      remainingValue: 22500000,
      selected: true,
    },
  ]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(value);
  };

  const toggleSelect = (id: string) => {
    setAssets(assets.map(asset => 
      asset.id === id ? { ...asset, selected: !asset.selected } : asset
    ));
  };

  const toggleSelectAll = () => {
    const allSelected = assets.every(a => a.selected);
    setAssets(assets.map(asset => ({ ...asset, selected: !allSelected })));
  };

  const selectedAssets = assets.filter(a => a.selected);
  const totalDepreciation = selectedAssets.reduce((sum, a) => sum + a.monthlyDepreciation, 0);

  const handleCalculate = () => {
    setShowVoucher(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-gray-900">Khấu hao Tài sản</h1>
          <p className="text-sm text-gray-500 mt-1">Tính và ghi nhận khấu hao tài sản cố định</p>
        </div>
      </div>

      {/* Period Selection */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-end">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Chọn kỳ khấu hao
            </label>
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleCalculate}
              className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Calculator className="w-5 h-5" />
              Tính Khấu hao
            </button>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Download className="w-5 h-5" />
              Xuất Excel
            </button>
          </div>
        </div>
      </div>

      {/* Info Alert */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
        <div className="flex-1">
          <p className="text-sm text-blue-900 font-medium">Thông tin khấu hao</p>
          <p className="text-sm text-blue-700 mt-1">
            Hệ thống sẽ tự động tính khấu hao cho các tài sản đang hoạt động và tự động sinh chứng từ kế toán.
            Tổng khấu hao kỳ này: <span className="font-semibold">{formatCurrency(totalDepreciation)}</span>
          </p>
        </div>
      </div>

      {/* Asset List */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left">
                  <input
                    type="checkbox"
                    checked={assets.every(a => a.selected)}
                    onChange={toggleSelectAll}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Mã TS
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Tên tài sản
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Phòng ban
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Nguyên giá
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  KH lũy kế
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  KH tháng này
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Còn lại
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {assets.map((asset) => (
                <tr key={asset.id} className={`hover:bg-gray-50 transition-colors ${!asset.selected ? 'opacity-50' : ''}`}>
                  <td className="px-6 py-4">
                    <input
                      type="checkbox"
                      checked={asset.selected}
                      onChange={() => toggleSelect(asset.id)}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm font-medium text-blue-600">{asset.code}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-900">{asset.name}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-600">{asset.department}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className="text-sm text-gray-900">{formatCurrency(asset.originalValue)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className="text-sm text-gray-600">{formatCurrency(asset.accumulatedDepreciation)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className="text-sm font-medium text-orange-600">{formatCurrency(asset.monthlyDepreciation)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className="text-sm font-medium text-green-600">{formatCurrency(asset.remainingValue)}</span>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-gray-50 border-t-2 border-gray-300">
              <tr>
                <td colSpan={6} className="px-6 py-4 text-right font-semibold text-gray-900">
                  Tổng khấu hao tháng này:
                </td>
                <td colSpan={2} className="px-6 py-4 text-right font-bold text-blue-600">
                  {formatCurrency(totalDepreciation)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Voucher Preview Modal */}
      {showVoucher && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-gray-900">Chứng từ Khấu hao</h3>
                <button
                  onClick={() => setShowVoucher(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Voucher Info */}
              <div className="grid grid-cols-2 gap-4 pb-4 border-b border-gray-200">
                <div>
                  <p className="text-sm text-gray-600">Số chứng từ</p>
                  <p className="font-semibold text-gray-900">CT-2026-KH-045</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Ngày chứng từ</p>
                  <p className="font-semibold text-gray-900">{new Date().toLocaleDateString('vi-VN')}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-sm text-gray-600">Diễn giải</p>
                  <p className="font-semibold text-gray-900">
                    Khấu hao TSCĐ tháng {new Date(selectedMonth).toLocaleDateString('vi-VN', { month: '2-digit', year: 'numeric' })}
                  </p>
                </div>
              </div>

              {/* Accounting Entries */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Bút toán</h4>
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-700">TK Nợ</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-700">TK Có</th>
                      <th className="px-4 py-2 text-right text-xs font-medium text-gray-700">Số tiền</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-700">Diễn giải</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <tr>
                      <td className="px-4 py-3">627</td>
                      <td className="px-4 py-3">214</td>
                      <td className="px-4 py-3 text-right font-medium">{formatCurrency(totalDepreciation)}</td>
                      <td className="px-4 py-3">Khấu hao TSCĐ</td>
                    </tr>
                  </tbody>
                  <tfoot className="bg-gray-50 font-semibold">
                    <tr>
                      <td colSpan={2} className="px-4 py-3 text-right">Tổng cộng:</td>
                      <td className="px-4 py-3 text-right text-blue-600">{formatCurrency(totalDepreciation)}</td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Asset Details */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Chi tiết tài sản</h4>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {selectedAssets.map((asset) => (
                    <div key={asset.id} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                      <div>
                        <p className="text-sm font-medium text-gray-900">{asset.code} - {asset.name}</p>
                        <p className="text-xs text-gray-600">{asset.department}</p>
                      </div>
                      <p className="text-sm font-medium text-gray-900">{formatCurrency(asset.monthlyDepreciation)}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-gray-200 flex justify-end gap-4">
              <button
                onClick={() => setShowVoucher(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Đóng
              </button>
              <button className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <FileText className="w-4 h-4" />
                Ghi sổ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
