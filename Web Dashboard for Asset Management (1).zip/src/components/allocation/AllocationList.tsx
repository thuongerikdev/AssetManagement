import { useState } from 'react';
import { Send, ArrowLeftRight, Search, Filter, Clock } from 'lucide-react';

interface AllocationRecord {
  id: string;
  date: string;
  type: 'assign' | 'recall' | 'transfer';
  asset: { code: string; name: string };
  fromDept?: string;
  toDept: string;
  fromUser?: string;
  toUser: string;
  status: 'pending' | 'completed';
  note: string;
}

const mockRecords: AllocationRecord[] = [
  {
    id: '1',
    date: '2026-02-10',
    type: 'assign',
    asset: { code: 'LAP-045', name: 'MacBook Air M2' },
    toDept: 'Marketing',
    toUser: 'Nguyễn Văn F',
    status: 'completed',
    note: 'Cấp phát cho nhân viên mới'
  },
  {
    id: '2',
    date: '2026-02-08',
    type: 'transfer',
    asset: { code: 'MON-023', name: 'Dell UltraSharp 27"' },
    fromDept: 'IT',
    toDept: 'Sales',
    fromUser: 'Trần Văn G',
    toUser: 'Lê Thị H',
    status: 'completed',
    note: 'Điều chuyển theo yêu cầu phòng ban'
  },
  {
    id: '3',
    date: '2026-02-05',
    type: 'recall',
    asset: { code: 'LAP-012', name: 'Dell XPS 15' },
    fromDept: 'Sales',
    toDept: 'Kho',
    fromUser: 'Phạm Thị D',
    toUser: 'Kho TSCĐ',
    status: 'completed',
    note: 'Thu hồi để bảo trì'
  },
  {
    id: '4',
    date: '2026-02-12',
    type: 'assign',
    asset: { code: 'LAP-067', name: 'HP EliteBook 840' },
    toDept: 'Admin',
    toUser: 'Hoàng Văn I',
    status: 'pending',
    note: 'Chờ ký biên bản bàn giao'
  },
];

const typeConfig = {
  assign: { label: 'Cấp phát', color: 'bg-green-100 text-green-700', icon: Send },
  recall: { label: 'Thu hồi', color: 'bg-orange-100 text-orange-700', icon: Send },
  transfer: { label: 'Điều chuyển', color: 'bg-blue-100 text-blue-700', icon: ArrowLeftRight },
};

const statusConfig = {
  pending: { label: 'Chờ xử lý', color: 'bg-yellow-100 text-yellow-700' },
  completed: { label: 'Hoàn thành', color: 'bg-green-100 text-green-700' },
};

export function AllocationList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState<'assign' | 'transfer'>('assign');

  const filteredRecords = mockRecords.filter(record => {
    const matchesSearch = record.asset.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.asset.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || record.type === filterType;
    return matchesSearch && matchesType;
  });

  const openModal = (type: 'assign' | 'transfer') => {
    setModalType(type);
    setShowModal(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-gray-900">Cấp phát & Điều chuyển</h1>
          <p className="text-sm text-gray-500 mt-1">Quản lý cấp phát và điều chuyển tài sản</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => openModal('assign')}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            <Send className="w-5 h-5" />
            Cấp phát
          </button>
          <button
            onClick={() => openModal('transfer')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <ArrowLeftRight className="w-5 h-5" />
            Điều chuyển
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Tìm kiếm theo mã hoặc tên tài sản..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">Tất cả loại</option>
              <option value="assign">Cấp phát</option>
              <option value="recall">Thu hồi</option>
              <option value="transfer">Điều chuyển</option>
            </select>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-5 h-5" />
              Bộ lọc
            </button>
          </div>
        </div>
      </div>

      {/* Records List */}
      <div className="space-y-4">
        {filteredRecords.map((record) => {
          const typeInfo = typeConfig[record.type];
          const TypeIcon = typeInfo.icon;
          
          return (
            <div key={record.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4 flex-1">
                  <div className={`p-3 rounded-lg ${typeInfo.color}`}>
                    <TypeIcon className="w-6 h-6" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className={`inline-flex px-3 py-1 text-xs font-medium rounded-full ${typeInfo.color}`}>
                        {typeInfo.label}
                      </span>
                      <span className={`inline-flex px-3 py-1 text-xs font-medium rounded-full ${statusConfig[record.status].color}`}>
                        {statusConfig[record.status].label}
                      </span>
                    </div>
                    
                    <h3 className="font-semibold text-gray-900 mb-2">
                      {record.asset.code} - {record.asset.name}
                    </h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      {record.fromDept && (
                        <div>
                          <p className="text-gray-600">Từ:</p>
                          <p className="text-gray-900">
                            {record.fromDept} - {record.fromUser}
                          </p>
                        </div>
                      )}
                      <div>
                        <p className="text-gray-600">{record.fromDept ? 'Đến:' : 'Cấp cho:'}</p>
                        <p className="text-gray-900">
                          {record.toDept} - {record.toUser}
                        </p>
                      </div>
                    </div>
                    
                    {record.note && (
                      <p className="text-sm text-gray-600 mt-2">
                        <span className="font-medium">Ghi chú:</span> {record.note}
                      </p>
                    )}
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                    <Clock className="w-4 h-4" />
                    {new Date(record.date).toLocaleDateString('vi-VN')}
                  </div>
                  <button className="text-sm text-blue-600 hover:underline">
                    Xem biên bản
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-gray-900">
                  {modalType === 'assign' ? 'Cấp phát Tài sản' : 'Điều chuyển Tài sản'}
                </h3>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>
            </div>
            
            <form className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Chọn tài sản <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Chọn tài sản</option>
                  <option value="1">LAP-045 - MacBook Air M2</option>
                  <option value="2">MON-067 - LG 27" 4K</option>
                  <option value="3">PRT-012 - HP LaserJet</option>
                </select>
              </div>

              {modalType === 'transfer' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Từ phòng ban
                    </label>
                    <input
                      type="text"
                      disabled
                      value="IT"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Từ người dùng
                    </label>
                    <input
                      type="text"
                      disabled
                      value="Nguyễn Văn A"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
                    />
                  </div>
                </>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {modalType === 'transfer' ? 'Đến phòng ban' : 'Phòng ban'} <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Chọn phòng ban</option>
                  <option value="it">IT</option>
                  <option value="sales">Sales</option>
                  <option value="marketing">Marketing</option>
                  <option value="admin">Admin</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {modalType === 'transfer' ? 'Đến người dùng' : 'Người nhận'} <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Nhập tên người nhận"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Ngày {modalType === 'transfer' ? 'điều chuyển' : 'cấp phát'} <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Ghi chú
                </label>
                <textarea
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Nhập ghi chú..."
                />
              </div>
            </form>

            <div className="p-6 border-t border-gray-200 flex justify-end gap-4">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Hủy
              </button>
              <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Lưu & Tạo biên bản
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
