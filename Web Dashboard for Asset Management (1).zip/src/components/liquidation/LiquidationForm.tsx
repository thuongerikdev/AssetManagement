import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Save, X, AlertCircle, Calculator } from 'lucide-react';

export function LiquidationForm() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    assetId: '',
    date: '',
    liquidationValue: '',
    reason: '',
    note: '',
  });

  const [assetInfo, setAssetInfo] = useState({
    code: 'LAP-034',
    name: 'HP ProBook 450',
    originalValue: 25000000,
    accumulatedDepreciation: 20000000,
    remainingValue: 5000000,
  });

  const liquidationValue = parseFloat(formData.liquidationValue) || 0;
  const profitLoss = liquidationValue - assetInfo.remainingValue;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Saving liquidation:', formData);
    navigate('/liquidation');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-gray-900">Tạo Phiếu thanh lý</h1>
          <p className="text-sm text-gray-500 mt-1">Ghi nhận thanh lý tài sản cố định</p>
        </div>
        <button
          onClick={() => navigate('/liquidation')}
          className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <X className="w-5 h-5" />
          Hủy
        </button>
      </div>

      {/* Info Alert */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
        <div className="flex-1">
          <p className="text-sm text-red-900 font-medium">Lưu ý khi thanh lý</p>
          <ul className="text-sm text-red-700 mt-2 space-y-1 list-disc list-inside">
            <li>Hệ thống sẽ tự động tính toán lãi/lỗ thanh lý</li>
            <li>Tự động sinh chứng từ giảm tài sản và bút toán kế toán</li>
            <li>Trạng thái tài sản sẽ được chuyển sang "Đã thanh lý"</li>
          </ul>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Asset Selection */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Chọn tài sản thanh lý</h3>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tài sản <span className="text-red-500">*</span>
            </label>
            <select
              name="assetId"
              value={formData.assetId}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">-- Chọn tài sản cần thanh lý --</option>
              <option value="1">LAP-034 - HP ProBook 450</option>
              <option value="2">LAP-023 - Dell Latitude 7490</option>
              <option value="3">MON-012 - Samsung 24" LED</option>
              <option value="4">PRT-005 - Canon Pixma</option>
            </select>
          </div>
        </div>

        {/* Asset Information */}
        {formData.assetId && (
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Thông tin tài sản</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-xs text-gray-600 mb-1">Mã tài sản</p>
                <p className="text-sm font-medium text-gray-900">{assetInfo.code}</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg col-span-2">
                <p className="text-xs text-gray-600 mb-1">Tên tài sản</p>
                <p className="text-sm font-medium text-gray-900">{assetInfo.name}</p>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-xs text-blue-700 mb-1">Nguyên giá</p>
                <p className="text-sm font-semibold text-blue-900">{formatCurrency(assetInfo.originalValue)}</p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-xs text-orange-700 mb-1">KH lũy kế</p>
                <p className="text-sm font-semibold text-orange-900">{formatCurrency(assetInfo.accumulatedDepreciation)}</p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-xs text-green-700 mb-1">Còn lại</p>
                <p className="text-sm font-semibold text-green-900">{formatCurrency(assetInfo.remainingValue)}</p>
              </div>
            </div>
          </div>
        )}

        {/* Liquidation Details */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Thông tin thanh lý</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ngày thanh lý <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Giá thanh lý (VNĐ) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                name="liquidationValue"
                value={formData.liquidationValue}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Lý do thanh lý <span className="text-red-500">*</span>
              </label>
              <select
                name="reason"
                value={formData.reason}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Chọn lý do</option>
                <option value="end_life">Hết thời gian sử dụng</option>
                <option value="damaged">Hỏng không sửa được</option>
                <option value="upgrade">Nâng cấp thiết bị mới</option>
                <option value="obsolete">Lạc hậu công nghệ</option>
                <option value="other">Lý do khác</option>
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ghi chú
              </label>
              <textarea
                name="note"
                value={formData.note}
                onChange={handleChange}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Các ghi chú khác về thanh lý..."
              />
            </div>
          </div>
        </div>

        {/* Calculation Result */}
        {formData.liquidationValue && (
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200 p-6">
            <div className="flex items-center gap-3 mb-4">
              <Calculator className="w-6 h-6 text-blue-600" />
              <h3 className="font-semibold text-gray-900">Tính toán Lãi/Lỗ thanh lý</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-1">Giá trị còn lại</p>
                <p className="font-bold text-gray-900">{formatCurrency(assetInfo.remainingValue)}</p>
              </div>
              <div className="bg-white rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-1">Giá thanh lý</p>
                <p className="font-bold text-gray-900">{formatCurrency(liquidationValue)}</p>
              </div>
              <div className={`bg-white rounded-lg p-4 ${profitLoss >= 0 ? 'border-2 border-green-500' : 'border-2 border-red-500'}`}>
                <p className="text-sm text-gray-600 mb-1">
                  {profitLoss >= 0 ? 'Lãi thanh lý' : 'Lỗ thanh lý'}
                </p>
                <p className={`font-bold text-lg ${profitLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(Math.abs(profitLoss))}
                </p>
              </div>
            </div>

            <div className="mt-4 p-4 bg-white rounded-lg">
              <p className="text-sm text-gray-700 font-medium mb-2">Bút toán sẽ được ghi nhận:</p>
              <div className="space-y-1 text-sm text-gray-600">
                <p>• Nợ TK 214: {formatCurrency(assetInfo.accumulatedDepreciation)} (Khấu hao lũy kế)</p>
                {profitLoss >= 0 ? (
                  <>
                    <p>• Nợ TK 111: {formatCurrency(liquidationValue)} (Thu tiền thanh lý)</p>
                    <p>• Có TK 711: {formatCurrency(profitLoss)} (Thu nhập khác)</p>
                  </>
                ) : (
                  <>
                    <p>• Nợ TK 111: {formatCurrency(liquidationValue)} (Thu tiền thanh lý)</p>
                    <p>• Nợ TK 811: {formatCurrency(Math.abs(profitLoss))} (Chi phí khác)</p>
                  </>
                )}
                <p>• Có TK 211: {formatCurrency(assetInfo.originalValue)} (Nguyên giá TSCĐ)</p>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex justify-end gap-4">
          <button
            type="button"
            onClick={() => navigate('/liquidation')}
            className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Hủy
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
          >
            <Save className="w-5 h-5" />
            Lưu & Sinh chứng từ
          </button>
        </div>
      </form>
    </div>
  );
}
