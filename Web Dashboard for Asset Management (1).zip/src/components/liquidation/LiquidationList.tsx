import { useState } from 'react';
import { Link } from 'react-router';
import { Plus, Search, Filter, Trash2 } from 'lucide-react';

interface LiquidationRecord {
  id: string;
  date: string;
  asset: { code: string; name: string };
  originalValue: number;
  accumulatedDepreciation: number;
  remainingValue: number;
  liquidationValue: number;
  profitLoss: number;
  status: 'pending' | 'approved' | 'completed';
  reason: string;
}

const mockRecords: LiquidationRecord[] = [
  {
    id: '1',
    date: '2026-01-15',
    asset: { code: 'LAP-023', name: 'Dell Latitude 7490' },
    originalValue: 35000000,
    accumulatedDepreciation: 33000000,
    remainingValue: 2000000,
    liquidationValue: 3000000,
    profitLoss: 1000000,
    status: 'completed',
    reason: 'Hết khấu hao, thanh lý do không sử dụng'
  },
  {
    id: '2',
    date: '2026-02-01',
    asset: { code: 'MON-012', name: 'Samsung 24" LED' },
    originalValue: 5000000,
    accumulatedDepreciation: 4500000,
    remainingValue: 500000,
    liquidationValue: 800000,
    profitLoss: 300000,
    status: 'completed',
    reason: 'Nâng cấp thiết bị mới'
  },
  {
    id: '3',
    date: '2026-02-10',
    asset: { code: 'PRT-005', name: 'Canon Pixma' },
    originalValue: 8000000,
    accumulatedDepreciation: 6000000,
    remainingValue: 2000000,
    liquidationValue: 1500000,
    profitLoss: -500000,
    status: 'approved',
    reason: 'Hỏng không sửa được'
  },
  {
    id: '4',
    date: '2026-02-12',
    asset: { code: 'LAP-034', name: 'HP ProBook 450' },
    originalValue: 25000000,
    accumulatedDepreciation: 20000000,
    remainingValue: 5000000,
    liquidationValue: 4000000,
    profitLoss: -1000000,
    status: 'pending',
    reason: 'Hết thời gian sử dụng'
  },
];

const statusConfig = {
  pending: { label: 'Chờ duyệt', color: 'bg-yellow-100 text-yellow-700' },
  approved: { label: 'Đã duyệt', color: 'bg-blue-100 text-blue-700' },
  completed: { label: 'Hoàn thành', color: 'bg-green-100 text-green-700' },
};

export function LiquidationList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredRecords = mockRecords.filter(record => {
    const matchesSearch = record.asset.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.asset.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || record.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-bold text-gray-900">Thanh lý - Giảm Tài sản</h1>
          <p className="text-sm text-gray-500 mt-1">Quản lý thanh lý và xử lý tài sản</p>
        </div>
        <Link
          to="/liquidation/new"
          className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Tạo Phiếu thanh lý
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <p className="text-sm text-gray-600 mb-1">Tổng thanh lý tháng này</p>
          <p className="font-bold text-gray-900">4 tài sản</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <p className="text-sm text-gray-600 mb-1">Giá trị thanh lý</p>
          <p className="font-bold text-green-600">9.3 triệu VNĐ</p>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <p className="text-sm text-gray-600 mb-1">Lãi/(Lỗ) thanh lý</p>
          <p className="font-bold text-red-600">-200 nghìn VNĐ</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Tìm kiếm theo mã hoặc tên tài sản..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="pending">Chờ duyệt</option>
              <option value="approved">Đã duyệt</option>
              <option value="completed">Hoàn thành</option>
            </select>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-5 h-5" />
              Bộ lọc
            </button>
          </div>
        </div>
      </div>

      {/* Liquidation Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Ngày TL
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Tài sản
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Nguyên giá
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Còn lại
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Giá TL
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Lãi/(Lỗ)
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Trạng thái
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-700 uppercase tracking-wider">
                  Thao tác
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredRecords.map((record) => (
                <tr key={record.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-900">
                      {new Date(record.date).toLocaleDateString('vi-VN')}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-sm font-medium text-blue-600">{record.asset.code}</p>
                      <p className="text-sm text-gray-600">{record.asset.name}</p>
                      <p className="text-xs text-gray-500 mt-1">{record.reason}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className="text-sm text-gray-900">{formatCurrency(record.originalValue)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className="text-sm text-gray-900">{formatCurrency(record.remainingValue)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className="text-sm font-medium text-gray-900">{formatCurrency(record.liquidationValue)}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className={`text-sm font-medium ${record.profitLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {formatCurrency(record.profitLoss)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${statusConfig[record.status].color}`}>
                      {statusConfig[record.status].label}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <button
                      className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                      title="Xem chi tiết"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
